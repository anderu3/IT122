const ogArray = ['a', 'c', 'd', 'b', 'e'];

const copiedArray = ogArray.slice();

const sortedArray = copiedArray.sort();

console.log('Original Array:', ogArray);
console.log('Sorted Array:', sortedArray);